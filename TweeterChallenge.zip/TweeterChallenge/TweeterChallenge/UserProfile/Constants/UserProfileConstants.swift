//
//  UserProfileModuleConstants.swift
//  TweeterChallenge
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import UIKit

struct UserProfileConstants {
    let defaultSectionHeaderHeight: CGFloat = 44.0
    let tweetsTableEstimatedRowSize: CGFloat = 600.0
    let tweetCellReuseId = "TweetCell"
    let tweetCellNibName = "TweetCell"
}
