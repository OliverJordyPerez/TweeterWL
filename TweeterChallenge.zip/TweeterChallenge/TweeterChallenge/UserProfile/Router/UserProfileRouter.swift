//
//  UserProfileRouter.swift
//  TweeterChallenge
//
//  Created Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import UIKit

final class UserProfileRouter: UserProfileWireframeProtocol {

    weak var viewController: UIViewController?

    static func createModule() -> UIViewController {
        // Change to get view from storyboard if not using progammatic UI
        let view = UserProfileViewController(nibName: nil, bundle: nil)
        let apiClient = TwitterAPIClient()
        let interactor = UserProfileInteractor(apiClient: apiClient)
        let router = UserProfileRouter()
        let presenter = UserProfilePresenter(view: view, interactor: interactor, router: router)

        view.presenter = presenter
        interactor.presenter = presenter
        router.viewController = view

        return view
    }
}
