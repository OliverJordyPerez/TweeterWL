//
//  UserProfileProtocols.swift
//  TweeterChallenge
//
//  Created Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import Foundation

//MARK: Wireframe
protocol UserProfileWireframeProtocol: class {

}

//MARK: Presenter
protocol UserProfilePresenterProtocol: class {

    var interactor: UserProfileInteractorInputProtocol? { get set }
    
    func viewDidLoad()
    func didSelectCell(at index: Int)
}

//MARK: Interactor
protocol UserProfileInteractorOutputProtocol: class {

    /* Interactor -> Presenter */
    func didGetUserProfile(with profile: UserProfile)
    func didGetUserTweets(with tweets: [Tweet])
}

protocol UserProfileInteractorInputProtocol: class {

    var presenter: UserProfileInteractorOutputProtocol?  { get set }

    /* Presenter -> Interactor */
    func getUserProfile()
    func getUserTweets()
}

//MARK: View
protocol UserProfileViewProtocol: class {

    var tweets: [FormattedTweet] { get set }
    var formattedProfile: FormattedUserProfile? { get set }
    
    var presenter: UserProfilePresenterProtocol?  { get set }

    /* Presenter -> ViewController */
}
