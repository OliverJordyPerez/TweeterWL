//
//  UserProfileInteractor.swift
//  TweeterChallenge
//
//  Created Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import UIKit

// MARK: - UserProfileInteractor
final class UserProfileInteractor {
    
    // MARK: - Properties
    weak var presenter: UserProfileInteractorOutputProtocol?
    let apiClient: APIClient
    
    // MARK: - Initializers
    init(apiClient: APIClient) {
        self.apiClient = apiClient
    }
    
}

// MARK: - UserProfileInteractorInputProtocol
extension UserProfileInteractor: UserProfileInteractorInputProtocol {
    func getUserTweets() {
        let request = APIRequest(method: .get, path: "/api/statuses/user_timeline")
        apiClient.perform(request) { [weak self] result in
               switch result {
               case .success(let response):
                if let response = try? response.decode(to: [Tweet].self) {
                       let tweets = response.body
                       self?.presenter?.didGetUserTweets(with: tweets)
                   } else {
                       print("Error")
                       // TODO: Handle Error
                   }
               case .failure:
                    print("Error")
                   // TODO: Handle Error
               }
           }
    }
    
    func getUserProfile() {
        let request = APIRequest(method: .get, path: "/api/user")
        apiClient.perform(request) { [weak self] result in
            switch result {
            case .success(let response):
                if let response = try? response.decode(to: UserProfile.self) {
                    let userProfile = response.body
                    self?.presenter?.didGetUserProfile(with: userProfile)
                } else {
                    print("Error")
                    // TODO: Handle Error
                }
            case .failure:
                 print("Error")
                // TODO: Handle Error
            }
        }
    }
}
