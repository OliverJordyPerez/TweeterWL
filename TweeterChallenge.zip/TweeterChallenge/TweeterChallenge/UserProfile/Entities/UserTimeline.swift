//
//  UserTimeline.swift
//  TweeterChallenge
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import Foundation

// MARK: - Tweet
struct Tweet: Codable {
    let createdAt: String
    let text: String
    let user: UserProfile
    let retweetCount, favoriteCount: Int
    let favorited, retweeted: Bool

    enum CodingKeys: String, CodingKey {
        case createdAt = "created_at"
        case text
        case user
        case retweetCount = "retweet_count"
        case favoriteCount = "favorite_count"
        case favorited, retweeted
    }
}
