//
//  User.swift
//  TweeterChallenge
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import Foundation

// MARK: - User
struct UserProfile: Codable {
    let id: Int
    let idStr: String
    let name: String
    let screenName: String
    let userDescription: String
    let followersCount: Int
    let profileBackgroundImageURLHTTPS: String
    let profileImageURLHTTPS: String
    let profileBannerURL: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case idStr = "id_str"
        case name
        case screenName = "screen_name"
        case userDescription = "description"
        case followersCount = "followers_count"
        case profileBackgroundImageURLHTTPS = "profile_background_image_url_https"
        case profileImageURLHTTPS = "profile_image_url_https"
        case profileBannerURL = "profile_banner_url"
    }
}
