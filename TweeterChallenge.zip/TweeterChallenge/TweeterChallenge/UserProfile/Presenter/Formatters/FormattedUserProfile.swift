//
//  FormattedProfileInfo.swift
//  TweeterChallenge
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import Foundation

struct FormattedUserProfile {
    let name: String
    let userName: String
    let profileImageUrl: URL?
    let backgroundImageUrl: URL?
    
    init(userProfile: UserProfile) {
        name = userProfile.name
        userName = "@\(userProfile.screenName)"
        profileImageUrl = URL(string: userProfile.profileImageURLHTTPS)
        backgroundImageUrl = URL(string: userProfile.profileBackgroundImageURLHTTPS)
    }
}
