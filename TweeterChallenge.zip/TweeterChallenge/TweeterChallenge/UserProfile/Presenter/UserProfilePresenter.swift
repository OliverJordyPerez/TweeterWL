//
//  UserProfilePresenter.swift
//  TweeterChallenge
//
//  Created Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import UIKit

// MARK: - UserProfilePresenter
final class UserProfilePresenter {
    weak private var view: UserProfileViewProtocol?
    var interactor: UserProfileInteractorInputProtocol?
    private let router: UserProfileWireframeProtocol
    
    init(view: UserProfileViewProtocol, interactor: UserProfileInteractorInputProtocol?, router: UserProfileWireframeProtocol) {
        self.view = view
        self.interactor = interactor
        self.router = router
    }
}

// MARK: - UserProfilePresenterProtocol
extension UserProfilePresenter: UserProfilePresenterProtocol {
    
    func viewDidLoad() {
        interactor?.getUserTweets()
        interactor?.getUserProfile()
    }
    
    func didSelectCell(at index: Int) {
        // TODO: Show Tweet
    }

}

// MARK: - UserProfileInteractorOutputProtocol
extension UserProfilePresenter: UserProfileInteractorOutputProtocol {
    
    func didGetUserProfile(with profile: UserProfile) {
        view?.formattedProfile = FormattedUserProfile(userProfile: profile)
    }
    
    func didGetUserTweets(with tweets: [Tweet]) {
        view?.tweets = tweets.map { FormattedTweet(tweet: $0) }
    }
}
