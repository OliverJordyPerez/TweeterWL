//
//  TweetCell.swift
//  TweeterChallenge
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import UIKit

final class TweetCell: UITableViewCell {

    @IBOutlet private var profileImageView: UIImageView!
    @IBOutlet private weak var userNameLabel: UILabel!
    @IBOutlet private weak var tweetMessageLabel: UILabel!
    
    func setupTweetInformation(with tweetInfo: FormattedTweet) {
        userNameLabel.text = tweetInfo.tweetUserName
        tweetMessageLabel.text = tweetInfo.tweetMessage
        setUserProfileImage(with: tweetInfo.tweetUserImageUrl)
    }
    
    //MARK: - Private Methods
    private func setUserProfileImage(with url: URL?) {
        if let profileImageURL = url {
            profileImageView.load(url: profileImageURL)
        } else {
            profileImageView = UIImageView(image: UIImage(named: "kitten"))
        }
    }
    
}
