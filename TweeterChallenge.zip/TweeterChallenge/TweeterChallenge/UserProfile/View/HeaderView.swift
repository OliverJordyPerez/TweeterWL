//
//  HeaderView.swift
//  TweeterChallenge
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import UIKit

final class UserHeaderView: UIView {
    // MARK: - Properties
    private let backgroundImage = UIImageView()
    private var profileImage = UIImageView()
    private let userLabel = UILabel()
    private let userNameLabel = UILabel()
    
    // MARK: - Initializers
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayout()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupLayout()
    }
    
    // MARK: - Instance methods
    func setProfileInformation(with profile: FormattedUserProfile) {
        userLabel.text = profile.name
        userNameLabel.text = profile.userName
        setUserProfileImage(with: profile.profileImageUrl)
        setUserProfileBackgroundImage(with: profile.backgroundImageUrl)
    }
    
    
    // MARK: - Private methods
    private func setUserProfileImage(with url: URL?) {
        if let profileImageURL = url {
            profileImage.load(url: profileImageURL)
        } else {
            profileImage = UIImageView(image: UIImage(named: "kitten"))
        }
    }
    
    private func setUserProfileBackgroundImage(with url: URL?) {
        if let backgroundImageURL = url {
            backgroundImage.load(url: backgroundImageURL)
        } else {
            backgroundImage.backgroundColor = .lightGray
        }
    }
}

// MARK: - UserHeaderView layout methods
extension UserHeaderView {
    private func setupLayout() {
        addBackgroundImageView()
        addProfileImageView()
        addUserLabel()
        addUserNameLabel()
    }
    
    private func addBackgroundImageView() {
        backgroundImage.contentMode = .scaleAspectFill
        addSubview(backgroundImage)
        backgroundImage.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            backgroundImage.widthAnchor.constraint(equalTo: widthAnchor),
            backgroundImage.heightAnchor.constraint(equalTo: heightAnchor),
            backgroundImage.centerXAnchor.constraint(equalTo: centerXAnchor),
            backgroundImage.centerYAnchor.constraint(equalTo: centerYAnchor)
        ])
    }
    
    private func addProfileImageView() {
        addSubview(profileImage)
        profileImage.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            profileImage.widthAnchor.constraint(equalToConstant: 100),
            profileImage.heightAnchor.constraint(equalToConstant: 100),
            profileImage.topAnchor.constraint(equalTo: topAnchor, constant: 32),
            profileImage.centerXAnchor.constraint(equalTo: centerXAnchor)
        ])
    }
    
    private func addUserLabel() {
        addSubview(userLabel)
        userLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            userLabel.topAnchor.constraint(equalTo: profileImage.bottomAnchor, constant: 8.0),
            userLabel.centerXAnchor.constraint(equalTo: profileImage.centerXAnchor)
        ])
        
    }
    
    private func addUserNameLabel() {
        addSubview(userNameLabel)
        userNameLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            userNameLabel.topAnchor.constraint(equalTo: userLabel.bottomAnchor, constant: 8.0),
            userNameLabel.centerXAnchor.constraint(equalTo: userLabel.centerXAnchor),
            bottomAnchor.constraint(equalTo: userNameLabel.bottomAnchor, constant: 16),
        ])
        
    }
}
