//
//  UserProfileViewController.swift
//  TweeterChallenge
//
//  Created Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import UIKit

final class UserProfileViewController: UIViewController, UserProfileViewProtocol {
    
    // MARK: - Properties
    let constants = UserProfileConstants()
    var presenter: UserProfilePresenterProtocol?
    let tweetsTable = UITableView(frame: .zero, style: .grouped)
    
    // MARK: - Observed properties
    var tweets: [FormattedTweet] = [] {
        didSet {
            DispatchQueue.main.async { [weak self] in
                self?.tweetsTable.reloadData()
            }
        }
    }
    var formattedProfile: FormattedUserProfile? {
        didSet {
            DispatchQueue.main.async { [weak self] in
                self?.tweetsTable.reloadData()
            }
        }
    }
    
    // MARK: - Life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter?.viewDidLoad()
        setupTableViewDelegateAndDataSource()
        setupTweetsTableLayout()
        registerCells()
    }
    
    // MARK: - Private methods
    private func setupTableViewDelegateAndDataSource() {
        tweetsTable.delegate = self
        tweetsTable.dataSource = self
    }
    
    private func setupTweetsTableLayout() {
        setTweetsTableHeight()
        tweetsTable.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tweetsTable)
        
        NSLayoutConstraint.activate([
            tweetsTable.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tweetsTable.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tweetsTable.topAnchor.constraint(equalTo: view.topAnchor),
            tweetsTable.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    private func setTweetsTableHeight() {
        tweetsTable.estimatedRowHeight = UITableView.automaticDimension
        tweetsTable.estimatedRowHeight = constants.tweetsTableEstimatedRowSize
        tweetsTable.sectionHeaderHeight = UITableView.automaticDimension
        tweetsTable.estimatedSectionHeaderHeight = constants.defaultSectionHeaderHeight
        
    }
    
    private func registerCells() {
        let tweetCellNib = UINib(nibName: constants.tweetCellNibName,bundle: nil)
        tweetsTable.register(tweetCellNib, forCellReuseIdentifier: constants.tweetCellReuseId)
    }
}

// MARK: - UITableViewDataSource extension
extension UserProfileViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let profile = formattedProfile else { return nil }
        let headerView = UserHeaderView()
        headerView.setProfileInformation(with: profile)
        return headerView
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        tweets.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: constants.tweetCellReuseId) as? TweetCell else {
            return UITableViewCell()
        }
        cell.setupTweetInformation(with: tweets[indexPath.row])
        return cell
    }
    
}

// MARK: - UITableViewDelegate extension
extension UserProfileViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        presenter?.didSelectCell(at: indexPath.row)
    }
}
