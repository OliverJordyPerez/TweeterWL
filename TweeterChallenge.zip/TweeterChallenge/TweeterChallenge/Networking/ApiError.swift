//
//  ApiError.swift
//  TweeterChallenge
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import Foundation

enum APIError: Error {
    case invalidURL
    case requestFailed
    case decodingFailure
}
