//
//  UserProfileRouterMock.swift
//  TweeterChallengeTests
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import Foundation
@testable import TweeterChallenge

class UserProfileRouterMock: UserProfileWireframeProtocol {
    
}
