//
//  UserProfileInteractorMock.swift
//  TweeterChallengeTests
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import Foundation
@testable import TweeterChallenge

class UserProfileInteractorMock: UserProfileInteractorInputProtocol {
    
    //MARK: - Spying properties
    var calls: [String] = []
    
    var presenter: UserProfileInteractorOutputProtocol?
    
    func getUserProfile() {
        calls.append(#function)
    }
    
    func getUserTweets() {
        calls.append(#function)
    }
    
}
