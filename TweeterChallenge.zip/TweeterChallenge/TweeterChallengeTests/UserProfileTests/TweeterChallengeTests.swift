//
//  TweeterChallengeTests.swift
//  TweeterChallengeTests
//
//  Created by Oliver Jordy Pérez Escamilla on 04/08/20.
//  Copyright © 2020 Oliver Jordy Pérez Escamilla. All rights reserved.
//

import XCTest
@testable import TweeterChallenge

class UserProfilePresenterTests: XCTestCase {
    
    var sut: UserProfilePresenter?
    var viewMock: UserProfileViewMock?
    var interactorMock: UserProfileInteractorMock?
    var routerMock: UserProfileRouterMock?
    
    override func setUp() {
        super.setUp()
        viewMock = UserProfileViewMock()
        interactorMock = UserProfileInteractorMock()
        routerMock = UserProfileRouterMock()
        
        sut = UserProfilePresenter(view: viewMock!,
                                   interactor: interactorMock!,
                                   router: routerMock!)
    }
    
    override func tearDown() {
        sut = nil
        viewMock = nil
        interactorMock = nil
        super.tearDown()
    }
    
    func testGetUserProfileIsCalled() {
        // Given
        let expectedCall = "getUserTweets()|getUserProfile()"
        
        // When
        sut?.viewDidLoad()
        
        // Then
        XCTAssertEqual(expectedCall, interactorMock?.calls.joined(separator: "|"))
    }
    
    
}
